﻿namespace PtesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.palavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btncompara = new System.Windows.Forms.Button();
            this.btninserir1 = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // palavra1
            // 
            this.palavra1.Location = new System.Drawing.Point(97, 34);
            this.palavra1.Name = "palavra1";
            this.palavra1.Size = new System.Drawing.Size(100, 26);
            this.palavra1.TabIndex = 0;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(97, 108);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 26);
            this.txtpalavra2.TabIndex = 1;
            // 
            // btncompara
            // 
            this.btncompara.Location = new System.Drawing.Point(54, 228);
            this.btncompara.Name = "btncompara";
            this.btncompara.Size = new System.Drawing.Size(181, 71);
            this.btncompara.TabIndex = 2;
            this.btncompara.Text = "comparar";
            this.btncompara.UseVisualStyleBackColor = true;
            // 
            // btninserir1
            // 
            this.btninserir1.Location = new System.Drawing.Point(298, 228);
            this.btninserir1.Name = "btninserir1";
            this.btninserir1.Size = new System.Drawing.Size(190, 71);
            this.btninserir1.TabIndex = 3;
            this.btninserir1.Text = "inserer o primeiro no meio do segundo";
            this.btninserir1.UseVisualStyleBackColor = true;
            // 
            // btninserir2
            // 
            this.btninserir2.Location = new System.Drawing.Point(565, 228);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(182, 71);
            this.btninserir2.TabIndex = 4;
            this.btninserir2.Text = "inseririr ** no meio do primeiro";
            this.btninserir2.UseVisualStyleBackColor = true;
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(12, 34);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(69, 20);
            this.lblpalavra1.TabIndex = 5;
            this.lblpalavra1.Text = "palavra1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(13, 108);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(69, 20);
            this.lblpalavra2.TabIndex = 6;
            this.lblpalavra2.Text = "palavra2";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir1);
            this.Controls.Add(this.btncompara);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.palavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox palavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btncompara;
        private System.Windows.Forms.Button btninserir1;
        private System.Windows.Forms.Button btninserir2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
    }
}