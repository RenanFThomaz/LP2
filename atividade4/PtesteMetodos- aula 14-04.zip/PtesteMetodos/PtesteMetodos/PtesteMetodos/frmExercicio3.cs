﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnremover_Click(object sender, EventArgs e)
        {
            txtpPalavra2.Text =
                txtpPalavra2.Text.Replace(txtPalavra1.Text,"");
        }

        private void btninverter_Click(object sender, EventArgs e)
        {
            char[] vetor= txtPalavra1.Text.ToCharArray();
            Array.Reverse(vetor);

            string auxiliar = new string(vetor);

            txtpPalavra2.Text = auxiliar;
        }
    }
}
