﻿namespace PtesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.btninverter = new System.Windows.Forms.Button();
            this.btnremover = new System.Windows.Forms.Button();
            this.txtpPalavra2 = new System.Windows.Forms.TextBox();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(55, 137);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(69, 20);
            this.lblpalavra2.TabIndex = 13;
            this.lblpalavra2.Text = "palavra2";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(54, 63);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(69, 20);
            this.lblpalavra1.TabIndex = 12;
            this.lblpalavra1.Text = "palavra1";
            // 
            // btninverter
            // 
            this.btninverter.Location = new System.Drawing.Point(485, 257);
            this.btninverter.Name = "btninverter";
            this.btninverter.Size = new System.Drawing.Size(286, 71);
            this.btninverter.TabIndex = 10;
            this.btninverter.Text = "inverte o 1º";
            this.btninverter.UseVisualStyleBackColor = true;
            this.btninverter.Click += new System.EventHandler(this.btninverter_Click);
            // 
            // btnremover
            // 
            this.btnremover.Location = new System.Drawing.Point(96, 257);
            this.btnremover.Name = "btnremover";
            this.btnremover.Size = new System.Drawing.Size(272, 71);
            this.btnremover.TabIndex = 9;
            this.btnremover.Text = "Remover 1º do 2º";
            this.btnremover.UseVisualStyleBackColor = true;
            this.btnremover.Click += new System.EventHandler(this.btnremover_Click);
            // 
            // txtpPalavra2
            // 
            this.txtpPalavra2.Location = new System.Drawing.Point(139, 137);
            this.txtpPalavra2.Name = "txtpPalavra2";
            this.txtpPalavra2.Size = new System.Drawing.Size(100, 26);
            this.txtpPalavra2.TabIndex = 8;
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(139, 63);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(100, 26);
            this.txtPalavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 598);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.btninverter);
            this.Controls.Add(this.btnremover);
            this.Controls.Add(this.txtpPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Button btninverter;
        private System.Windows.Forms.Button btnremover;
        private System.Windows.Forms.TextBox txtpPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
    }
}