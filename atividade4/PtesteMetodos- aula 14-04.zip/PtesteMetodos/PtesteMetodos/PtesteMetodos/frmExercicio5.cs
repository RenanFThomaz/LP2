﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (num1 >= num2)
            {
                MessageBox.Show("O número 1 é menor que o número 2.");

            }

            Random rnd = new Random();
            int sorteado = rnd.Next(num1, num2 + 1);

            MessageBox.Show("Número sorteado: " + sorteado);
        }
    }
}
