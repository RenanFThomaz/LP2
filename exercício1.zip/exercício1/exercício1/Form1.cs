﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercício1
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura) || altura <= 0)
        {
                MessageBox.Show("Altura inválido");
                txtAltura.Focus();

            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;

            txtVolume.Text = volume.ToString("n2");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtVolume.Clear();
            txtAltura.Clear();
            txtRaio.Clear();
            raio =0;
            altura = 0;
            volume = 0;
            txtRaio.Focus();

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
            {
                return;
            }
            if (!double.TryParse(txtRaio.Text,out raio) || raio <=0)
        {
                MessageBox.Show("raio inválido");
                txtRaio.Focus();

            }
        }
    }
}
