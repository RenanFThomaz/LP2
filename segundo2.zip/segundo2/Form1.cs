﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace segundo2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox2.Items.Add("Florianópolis");
            listBox2.Items.Add("Rio Claro");
            listBox2.Items.Add("Votororantim");
            listBox2.Items.Add("Adamantina");
            listBox2.Items.Add("São Roque");
            listBox2.Items.Add("Sorocaba");
            listBox2.Sorted=true;
            listBox2.SelectedIndex = 0;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Nome Vazio");
            }
            else
            {
                MessageBox.Show("Nome: " + textBox1.Text);
            }
            if (checkBox1.Checked)
                MessageBox.Show("é estrangeiro");
            else
                MessageBox.Show("Não é estrangeiro");
            if
                (comboBox1.SelectedIndex == -1)
                MessageBox.Show("não esoclheu origem");
            else
                MessageBox.Show("Origem: "+ comboBox1.SelectedItem);

            MessageBox.Show("Destino: " + listBox2.SelectedItem);

            if (radioButton1.Checked)
                MessageBox.Show("Aluguel de carro");
            else
                MessageBox.Show("Não inclui aluguel");
            
            string preferencias = "";
            for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++) 
            
                    preferencias = preferencias + "/n"+ checkedListBox1.CheckedItems[i];

            MessageBox.Show(preferencias);

            

        }
    }
}
